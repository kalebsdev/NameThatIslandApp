﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace IC20
{
    public partial class HawaiianIslandsForm : Form
    {
        StreamReader reader = File.OpenText("hawaiianIslands.txt");

        List<string> islandsList = new List<string>();

        //define const
        //define variable
        const int TOTAL_ISLANDS = 18;
        int islandsLeftToGuess = TOTAL_ISLANDS;
        public HawaiianIslandsForm()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void showHintsButton_Click(object sender, EventArgs e)
        {
            showHintsButton.Hide();
            hideHintsButton.Show();
            hintsListBox.Show();
        }

        private void hideHintsButton_Click(object sender, EventArgs e)
        {
            hideHintsButton.Hide();
            showHintsButton.Show();
            hintsListBox.Hide();
        }

        private void HawaiianIslandsForm_Load(object sender, EventArgs e)
        {
            hideHintsButton.Hide();
            hintsListBox.Hide();
            showHintsButton.Show();
            resultLabel.Hide();
            incorrectLabel.Hide();

            while (!reader.EndOfStream)
	{
	         string island = reader.ReadLine();
                //add isle
                islandsList.Add(island);
                //display
                hintsListBox.Items.Add(island);
	}

            //close the txt file
            reader.Close();
        }

        private void clearAllButton_Click(object sender, EventArgs e)
        {
            showHintsButton.Show();
            hideHintsButton.Hide();
            hintsListBox.Hide();
            incorrectLabel.Hide();
            islandNameTextBox.Clear();
            correctGuessesListBox.Items.Clear();
            islandsLeftToGuess = 18;
            islandsLeftToGuessLabel.Text = islandsLeftToGuess.ToString() + (" islands left to guess!");
            
            islandNameTextBox.Focus();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            //determine if guess is in list
            string guess = islandNameTextBox.Text;

            if (islandsList.Contains(guess) && !correctGuessesListBox.Items.Contains(guess))
            {
                //show result for 2 sec
                //correct in green
                resultLabel.Show();
                resultLabel.Text = "Correct!";
                resultLabel.ForeColor = Color.Green;
                this.Update();
                System.Threading.Thread.Sleep(2000);
                resultLabel.Hide();
                this.Update();


                //add isles to listbox
                correctGuessesListBox.Items.Add(guess);
                //subtract 1 from isles
                islandsLeftToGuess--;
                //display
                islandsLeftToGuessLabel.Text = islandsLeftToGuess.ToString() + (" islands left to guess!");
                
            }

            else
            {
                incorrectLabel.Show();

            }

            islandNameTextBox.Focus();
            islandNameTextBox.SelectAll();

        }
    }
}
