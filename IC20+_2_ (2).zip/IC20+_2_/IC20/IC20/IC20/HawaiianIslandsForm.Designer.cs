﻿namespace IC20
{
    partial class HawaiianIslandsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.correctGuessesListBox = new System.Windows.Forms.ListBox();
            this.submitButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.islandNameTextBox = new System.Windows.Forms.TextBox();
            this.resultLabel = new System.Windows.Forms.Label();
            this.clearAllButton = new System.Windows.Forms.Button();
            this.islandsLeftToGuessLabel = new System.Windows.Forms.Label();
            this.hintsListBox = new System.Windows.Forms.ListBox();
            this.showHintsButton = new System.Windows.Forms.Button();
            this.hideHintsButton = new System.Windows.Forms.Button();
            this.incorrectLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // correctGuessesListBox
            // 
            this.correctGuessesListBox.FormattingEnabled = true;
            this.correctGuessesListBox.Location = new System.Drawing.Point(44, 198);
            this.correctGuessesListBox.Name = "correctGuessesListBox";
            this.correctGuessesListBox.Size = new System.Drawing.Size(171, 238);
            this.correctGuessesListBox.Sorted = true;
            this.correctGuessesListBox.TabIndex = 0;
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(77, 68);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(103, 24);
            this.submitButton.TabIndex = 1;
            this.submitButton.Text = "&Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(292, 342);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 39);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "E&xit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(30, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(197, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "Enter Name of Hawaiian Island :";
            // 
            // islandNameTextBox
            // 
            this.islandNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.islandNameTextBox.Location = new System.Drawing.Point(250, 37);
            this.islandNameTextBox.Name = "islandNameTextBox";
            this.islandNameTextBox.Size = new System.Drawing.Size(142, 22);
            this.islandNameTextBox.TabIndex = 0;
            this.islandNameTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // resultLabel
            // 
            this.resultLabel.AutoSize = true;
            this.resultLabel.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resultLabel.ForeColor = System.Drawing.Color.Green;
            this.resultLabel.Location = new System.Drawing.Point(246, 70);
            this.resultLabel.Name = "resultLabel";
            this.resultLabel.Size = new System.Drawing.Size(62, 19);
            this.resultLabel.TabIndex = 6;
            this.resultLabel.Text = "Correct!!";
            // 
            // clearAllButton
            // 
            this.clearAllButton.Location = new System.Drawing.Point(292, 261);
            this.clearAllButton.Name = "clearAllButton";
            this.clearAllButton.Size = new System.Drawing.Size(75, 39);
            this.clearAllButton.TabIndex = 2;
            this.clearAllButton.Text = "C&lear All";
            this.clearAllButton.UseVisualStyleBackColor = true;
            this.clearAllButton.Click += new System.EventHandler(this.clearAllButton_Click);
            // 
            // islandsLeftToGuessLabel
            // 
            this.islandsLeftToGuessLabel.AutoSize = true;
            this.islandsLeftToGuessLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.islandsLeftToGuessLabel.Location = new System.Drawing.Point(57, 171);
            this.islandsLeftToGuessLabel.Name = "islandsLeftToGuessLabel";
            this.islandsLeftToGuessLabel.Size = new System.Drawing.Size(145, 16);
            this.islandsLeftToGuessLabel.TabIndex = 8;
            this.islandsLeftToGuessLabel.Text = "18 islands left to guess!";
            // 
            // hintsListBox
            // 
            this.hintsListBox.FormattingEnabled = true;
            this.hintsListBox.Location = new System.Drawing.Point(502, 198);
            this.hintsListBox.Name = "hintsListBox";
            this.hintsListBox.Size = new System.Drawing.Size(121, 238);
            this.hintsListBox.Sorted = true;
            this.hintsListBox.TabIndex = 9;
            // 
            // showHintsButton
            // 
            this.showHintsButton.Location = new System.Drawing.Point(510, 167);
            this.showHintsButton.Name = "showHintsButton";
            this.showHintsButton.Size = new System.Drawing.Size(103, 24);
            this.showHintsButton.TabIndex = 4;
            this.showHintsButton.Text = "&Show Hints";
            this.showHintsButton.UseVisualStyleBackColor = true;
            this.showHintsButton.Click += new System.EventHandler(this.showHintsButton_Click);
            // 
            // hideHintsButton
            // 
            this.hideHintsButton.Location = new System.Drawing.Point(510, 167);
            this.hideHintsButton.Name = "hideHintsButton";
            this.hideHintsButton.Size = new System.Drawing.Size(103, 24);
            this.hideHintsButton.TabIndex = 10;
            this.hideHintsButton.Text = "&Hide Hints";
            this.hideHintsButton.UseVisualStyleBackColor = true;
            this.hideHintsButton.Click += new System.EventHandler(this.hideHintsButton_Click);
            // 
            // incorrectLabel
            // 
            this.incorrectLabel.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.incorrectLabel.ForeColor = System.Drawing.Color.Red;
            this.incorrectLabel.Location = new System.Drawing.Point(314, 68);
            this.incorrectLabel.Name = "incorrectLabel";
            this.incorrectLabel.Size = new System.Drawing.Size(107, 22);
            this.incorrectLabel.TabIndex = 11;
            this.incorrectLabel.Text = "Incorrect :(";
            this.incorrectLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // HawaiianIslandsForm
            // 
            this.AcceptButton = this.submitButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::IC20.Properties.Resources.HawaiianIslands;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(624, 461);
            this.Controls.Add(this.incorrectLabel);
            this.Controls.Add(this.hideHintsButton);
            this.Controls.Add(this.showHintsButton);
            this.Controls.Add(this.hintsListBox);
            this.Controls.Add(this.islandsLeftToGuessLabel);
            this.Controls.Add(this.clearAllButton);
            this.Controls.Add(this.resultLabel);
            this.Controls.Add(this.islandNameTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.correctGuessesListBox);
            this.Name = "HawaiianIslandsForm";
            this.Text = "The Hawaiian Islands";
            this.Load += new System.EventHandler(this.HawaiianIslandsForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox correctGuessesListBox;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox islandNameTextBox;
        private System.Windows.Forms.Label resultLabel;
        private System.Windows.Forms.Button clearAllButton;
        private System.Windows.Forms.Label islandsLeftToGuessLabel;
        private System.Windows.Forms.ListBox hintsListBox;
        private System.Windows.Forms.Button showHintsButton;
        private System.Windows.Forms.Button hideHintsButton;
        private System.Windows.Forms.Label incorrectLabel;
    }
}

